function index_to_shortname( index ){
    return ["csrf","mixed_resource","hsts","directory_listing","x_frame_options","interesting_responses","insecure_cookies","http_only_cookies"][index];
}

function index_to_severity( index ){
    return {"csrf":"high","mixed_resource":"medium","hsts":"medium","directory_listing":"low","x_frame_options":"low","interesting_responses":"informational","insecure_cookies":"informational","http_only_cookies":"informational"}[index_to_shortname(index)];
}

function renderCharts() {
    if( window.renderedCharts )
    window.renderedCharts = true;

    c3.generate({
        bindto: '#chart-issues',
        data: {
            columns: [
                ["Trusted",2,2,1,1,1,9,1,1],
                ["Untrusted",0,0,0,0,0,0,0,0],
                ["Severity",4,3,3,2,2,1,1,1]
            ],
            axes: {
                Severity: 'y2'
            },
            type: 'bar',
            groups: [
                ['Trusted', 'Untrusted']
            ],
            types: {
                Severity: 'line'
            },
            onclick: function (d) {
                var location;

                if( d.name.toLowerCase() == 'severity' ) {
                    location = 'summary/issues/trusted/severity/' + index_to_severity(d.x);
                } else {
                    location = 'summary/issues/' + d.name.toLowerCase() + '/severity/' +
                        index_to_severity(d.x) + '/' + index_to_shortname(d.x);
                }

                goToLocation( location );
            }
        },
        regions: [{"class":"severity-high","start":0,"end":0},{"class":"severity-medium","start":1,"end":2},{"class":"severity-low","start":3,"end":4},{"class":"severity-informational","start":5}],
        axis: {
            x: {
                type: 'category',
                categories: ["Cross-Site Request Forgery","Mixed Resource","Missing 'Strict-Transport-Security' header","Directory listing","Missing 'X-Frame-Options' header","Interesting response","Insecure cookie","HttpOnly cookie"],
                tick: {
                    rotate: 15
                }
            },
            y: {
                label: {
                    text: 'Amount of logged issues',
                    position: 'outer-center'
                }
            },
            y2: {
                label: {
                    text: 'Severity',
                    position: 'outer-center'
                },
                show: true,
                type: 'category',
                categories: [1, 2, 3, 4],
                tick: {
                    format: function (d) {
                        return ["Informational","Low","Medium","High"][d - 1]
                    }
                }
            }
        },
        padding: {
            bottom: 40
        },
        color: {
            pattern: [ '#1f77b4', '#d62728', '#ff7f0e' ]
        }
    });

    c3.generate({
        bindto: '#chart-trust',
        data: {
            type: 'pie',
            columns: [["Trusted",18],["Untrusted",0]]
        },
        pie: {
            onclick: function (d) { goToLocation( 'summary/issues/' + d.id.toLowerCase() ) }
        },
        color: {
            pattern: [ '#1f77b4', '#d62728' ]
        }
    });

    c3.generate({
        bindto: '#chart-elements',
        data: {
            type: 'pie',
            columns: [["form",2],["cookie",2],["body",2],["server",12]]
        }
    });

    c3.generate({
        bindto: '#chart-severities',
        data: {
            type: 'pie',
            columns: [["high",2],["medium",3],["low",2],["informational",11]]
        },
        color: {
            pattern: [ '#d62728', '#ff7f0e', '#ffbb78', '#1f77b4' ]
        },
        pie: {
            onclick: function (d) {
                goToLocation( 'summary/issues/trusted/severity/' + d.id );
            }
        }
    });

}
